# Assignment 2
**Due March 12<sup>th</sup> before class**

## Task 
Starting with the code handout, and complete the RSS reader app. Make
sure
1. The list is cleaned up (CSS).
2. The details tab displays info; not JSON (JS + CSS).

## Submission/Grading
Demo in class.
