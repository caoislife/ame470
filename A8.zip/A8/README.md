# Assignment 5
** Due April 16<sup>th</sup> before class. **

## Task 
Starting with the code handout, complete the responsive behavior of the
Image uploader app.

Refer to ``rssApp/`` for techniques of responsive design.

## Submission/Grading
Demo in class.
