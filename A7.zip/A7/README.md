# Assignment 8
** Due April 25<sup>rd</sup> in class. **

## Task 
Host the 'Image Library' app you developed for this class on an AWS EC2
instance. Your submission will be presented in the last class of the
semester.

## Submission/Grading
Demo in class.
